﻿import { fallbackCovid, fallbackGdp, loadCountryHistory, loadCovidRows, loadGdpMap, loadWorldFeatures } from "./data.js";
import { formatCompact, formatSigned } from "./format.js";
import { createGlobe } from "./globe.js";
import { createMap2d } from "./map2d.js";
import { buildCountryTimeline, getInitialTimeIndex, getSelectedDayMeta, getSelectedLabel, getTimePoint, TIMELINE_DAYS } from "./timeline.js";
import { initAiAssistant } from "./ai-assistant.js";

const config = {
    minPopulation: 250000,
    historyCountryCount: 72
};

const dom = {
    stage: document.getElementById("stage"),
    viewGlobe: document.getElementById("viewGlobe"),
    viewMap2d: document.getElementById("viewMap2d"),
    mapCanvas: document.getElementById("mapCanvas"),
    modeToggle: document.getElementById("modeToggle"),
    tooltip: document.getElementById("tooltip"),
    loading: document.getElementById("loading"),
    loadingText: document.getElementById("loadingText"),
    status: document.getElementById("status"),
    countryName: document.getElementById("countryName"),
    casesValue: document.getElementById("casesValue"),
    deathsValue: document.getElementById("deathsValue"),
    shockValue: document.getElementById("shockValue"),
    recoveryValue: document.getElementById("recoveryValue"),
    detailNote: document.getElementById("detailNote"),
    timelineSlider: document.getElementById("timelineSlider"),
    timelineValue: document.getElementById("timelineValue"),
    timelineLabel: document.getElementById("timelineLabel"),
    playToggle: document.getElementById("playToggle"),
    jumpStart: document.getElementById("jumpStart"),
    chartCountry: document.getElementById("chartCountry"),
    shockChip: document.getElementById("shockChip"),
    bar2019: document.getElementById("bar2019"),
    bar2020: document.getElementById("bar2020"),
    bar2021: document.getElementById("bar2021"),
    bar2022: document.getElementById("bar2022"),
    bar2023: document.getElementById("bar2023"),
    bar2019Value: document.getElementById("bar2019Value"),
    bar2020Value: document.getElementById("bar2020Value"),
    bar2021Value: document.getElementById("bar2021Value"),
    bar2022Value: document.getElementById("bar2022Value"),
    bar2023Value: document.getElementById("bar2023Value"),
    countrySearch: document.getElementById("countrySearch"),
    countrySearchInput: document.getElementById("countrySearchInput"),
    countrySearchResults: document.getElementById("countrySearchResults"),
    sourcePanel: document.getElementById("sourcePanel"),
    sourceStatusBadge: document.getElementById("sourceStatusBadge"),
    compareToggle: document.getElementById("compareToggle"),
    comparePanel: document.getElementById("comparePanel"),
    compareClear: document.getElementById("compareClear"),
    compareClose: document.getElementById("compareClose"),
    compareNameA: document.getElementById("compareNameA"),
    compareNameB: document.getElementById("compareNameB"),
    compareMetricsA: document.getElementById("compareMetricsA"),
    compareMetricsB: document.getElementById("compareMetricsB"),
    compareHint: document.getElementById("compareHint")
};

const state = {
    countries: [],
    selectedCountry: null,
    lockedCountryIso: null,
    selectedTimeIndex: getInitialTimeIndex(window.location.search),
    viewMode: "globe",
    isPlaying: false,
    playTimer: null,
    sourceSummary: "live data sources",
    compareMode: false,
    compareA: null,
    compareB: null,
    compareSlotNext: "A"
};

const globe = createGlobe({
    stage: dom.stage,
    initialTimeIndex: state.selectedTimeIndex,
    onCountryHover: handleCountryHover,
    onCountryClick: handleCountryClick
});

const map2d = createMap2d(dom.mapCanvas, {
    onSelect: handleCountryClick,
    onHover: handleCountryHover
});

function setStatus(text) {
    dom.status.textContent = text;
    dom.loadingText.textContent = text;
}

function setLoading(isLoading) {
    dom.loading.classList.toggle("is-hidden", !isLoading);
}

function consolidateCovidRows(rows) {
    const result = [];
    let chinaRow = null;

    for (const row of rows) {
        const iso3 = row.iso3;
        const name = String(row.name || row.country || "");
        const isTaiwan = iso3 === "TWN" || /taiwan/i.test(name);

        if (iso3 === "CHN") {
            chinaRow = { ...row, name: "China" };
            result.push(chinaRow);
            continue;
        }

        if (isTaiwan) {
            if (!chinaRow) {
                chinaRow = {
                    name: "China",
                    country: "China",
                    iso3: "CHN",
                    lat: 35,
                    lng: 105,
                    cases: 0,
                    deaths: 0,
                    population: 0
                };
                result.push(chinaRow);
            }
            chinaRow.cases += Number(row.cases || 0);
            chinaRow.deaths += Number(row.deaths || 0);
            chinaRow.population += Number(row.population || 0);
            continue;
        }

        result.push(row);
    }

    return result;
}

function normalizeCountries(covidRows, gdpMap) {
    return consolidateCovidRows(covidRows)
        .map((row) => {
            const gdp = gdpMap[row.iso3];
            if (!row.iso3 || !gdp || !Number.isFinite(row.lat) || !Number.isFinite(row.lng) || row.population < config.minPopulation) {
                return null;
            }
            const shock = gdp.y2020 - gdp.y2019;
            const recovery = gdp.y2023 - gdp.y2020;
            const casesPerMillion = (row.cases / row.population) * 1000000;
            const exposure = Math.log10(casesPerMillion + 10) * Math.max(0.7, Math.min(14, Math.abs(Math.min(0, shock))));
            return {
                name: row.name || row.country,
                iso3: row.iso3,
                lat: row.lat,
                lng: row.lng,
                cases: row.cases,
                deaths: row.deaths,
                population: row.population,
                gdp2019: gdp.y2019,
                gdp2020: gdp.y2020,
                gdp2021: gdp.y2021,
                gdp2022: gdp.y2022,
                gdp2023: gdp.y2023,
                shock,
                recovery,
                exposure,
                timeline: buildCountryTimeline(row, gdp)
            };
        })
        .filter(Boolean)
        .sort((a, b) => b.exposure - a.exposure);
}

function getLeadCountry() {
    if (state.lockedCountryIso) {
        return state.countries.find((item) => item.iso3 === state.lockedCountryIso) || state.selectedCountry || state.countries[0] || null;
    }
    if (state.selectedTimeIndex === 0) {
        return state.countries.find((item) => item.iso3 === "CHN") || state.countries[0] || null;
    }
    const ranked = [...state.countries]
        .filter((item) => getTimePoint(item, state.selectedTimeIndex).cases > 0)
        .sort((a, b) => getTimePoint(b, state.selectedTimeIndex).exposure - getTimePoint(a, state.selectedTimeIndex).exposure);

    return ranked[0] || state.selectedCountry || state.countries[0] || null;
}

function formatGrowth(value) {
    return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;
}

function syncMapView() {
    if (!state.countries.length) {
        return;
    }
    map2d.setCountries(state.countries);
    map2d.setTimeIndex(state.selectedTimeIndex);
    map2d.setSelected(state.lockedCountryIso || state.selectedCountry?.iso3 || null);
}

function setViewMode(mode) {
    state.viewMode = mode === "map2d" ? "map2d" : "globe";
    const isMap2d = state.viewMode === "map2d";
    dom.viewGlobe.hidden = isMap2d;
    dom.viewMap2d.hidden = !isMap2d;
    dom.modeToggle.textContent = isMap2d ? "3D Globe" : "2D Map";
    dom.modeToggle.setAttribute("aria-pressed", String(isMap2d));
    if (dom.compareHint) {
        dom.compareHint.textContent = isMap2d
            ? "Click countries on the map to fill compare slots"
            : "Click countries on the globe to fill compare slots";
    }
    hideTooltip();
    syncMapView();
    if (isMap2d) {
        requestAnimationFrame(() => map2d.resize());
    }
}

function normalizeSearch(value) {
    return String(value || "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, " ")
        .trim();
}

function getCountrySearchMatches(query) {
    const normalizedQuery = normalizeSearch(query);
    if (!normalizedQuery) {
        return [];
    }

    return state.countries
        .map((country) => {
            const name = normalizeSearch(country.name);
            const iso = String(country.iso3 || "").toLowerCase();
            let score = 0;

            if (iso === normalizedQuery) score = 100;
            else if (name === normalizedQuery) score = 96;
            else if (name.startsWith(normalizedQuery)) score = 82;
            else if (iso.startsWith(normalizedQuery)) score = 76;
            else if (name.includes(normalizedQuery)) score = 56;

            return { country, score };
        })
        .filter((entry) => entry.score > 0)
        .sort((a, b) => b.score - a.score || a.country.name.localeCompare(b.country.name))
        .slice(0, 8)
        .map((entry) => entry.country);
}

function setSearchResultsVisible(isVisible) {
    dom.countrySearchResults.hidden = !isVisible;
    dom.countrySearchInput.setAttribute("aria-expanded", String(isVisible));
}

function renderSearchResults(matches, query) {
    dom.countrySearchResults.innerHTML = "";

    if (!query.trim()) {
        setSearchResultsVisible(false);
        return;
    }

    if (!matches.length) {
        const empty = document.createElement("div");
        empty.className = "search-empty";
        empty.textContent = "No country found in the current dataset.";
        dom.countrySearchResults.appendChild(empty);
        setSearchResultsVisible(true);
        return;
    }

    matches.forEach((country) => {
        const point = getTimePoint(country, state.selectedTimeIndex);
        const option = document.createElement("button");
        const label = document.createElement("span");
        const name = document.createElement("strong");
        const meta = document.createElement("small");
        const shock = document.createElement("em");

        option.className = "search-option";
        option.type = "button";
        option.setAttribute("role", "option");
        option.dataset.iso3 = country.iso3;
        name.textContent = country.name;
        meta.textContent = `${country.iso3} / ${formatCompact(point.cases)} cases / ${formatCompact(point.deaths)} deaths`;
        shock.textContent = formatSigned(country.shock);
        label.append(name, meta);
        option.append(label, shock);
        dom.countrySearchResults.appendChild(option);
    });

    setSearchResultsVisible(true);
}

function selectCountryFromSearch(country) {
    if (!country) {
        return;
    }

    stopPlayback();
    state.lockedCountryIso = country.iso3;
    state.selectedCountry = country;
    globe.setLockedCountry(country.iso3);
    map2d.setSelected(country.iso3);
    selectCountry(country);
    showTooltip(country, 0, window.innerHeight * 0.48);
    dom.countrySearchInput.value = country.name;
    setSearchResultsVisible(false);
    setStatus(`Showing detailed COVID and GDP data for ${country.name} at ${getSelectedLabel(state.selectedTimeIndex)}.`);
}

function submitCountrySearch() {
    const matches = getCountrySearchMatches(dom.countrySearchInput.value);
    if (!matches.length) {
        renderSearchResults(matches, dom.countrySearchInput.value);
        setStatus("No matching country found. Try a country name or ISO code such as AUS, CHN, or USA.");
        return;
    }
    selectCountryFromSearch(matches[0]);
}

function renderCompareSlot(country, nameEl, metricsEl) {
    if (!country) {
        nameEl.textContent = nameEl.id === "compareNameA" ? "Click a country on the globe" : "Click a second country";
        nameEl.className = "compare-slot-name empty";
        metricsEl.innerHTML = "";
        return;
    }

    nameEl.textContent = country.name;
    nameEl.className = "compare-slot-name";

    const point = getTimePoint(country, state.selectedTimeIndex);

    const values = [
        { year: "2019", v: country.gdp2019, color: "#2563eb" },
        { year: "2020", v: country.gdp2020, color: "#be123c" },
        { year: "2021", v: country.gdp2021, color: "#d97706" },
        { year: "2022", v: country.gdp2022, color: "#3b82f6" },
        { year: "2023", v: country.gdp2023, color: "#047857" }
    ];
    const scaleMax = Math.max(4, ...values.map((e) => Math.abs(e.v)));

    metricsEl.innerHTML = `
        <div class="compare-metric-row">
            <span>GDP Shock</span>
            <span class="compare-metric-val" style="color:${country.shock <= -4 ? "var(--red)" : "var(--mint)"}">${formatSigned(country.shock)}</span>
        </div>
        <div class="compare-metric-row">
            <span>Recovery</span>
            <span class="compare-metric-val" style="color:var(--amber)">${formatSigned(country.recovery)}</span>
        </div>
        <div class="compare-metric-row">
            <span>Cases</span>
            <span class="compare-metric-val" style="color:var(--cyan)">${formatCompact(point.cases)}</span>
        </div>
        <div class="compare-mini-bars">
            ${values.map((e) => {
                const h = Math.max(4, (Math.abs(e.v) / scaleMax) * 32);
                return `<div class="compare-mini-bar" style="height:${h}px;background:${e.color}" title="${e.year}: ${formatSigned(e.v)}"></div>`;
            }).join("")}
        </div>
    `;
}

function renderComparePanel() {
    renderCompareSlot(state.compareA, dom.compareNameA, dom.compareMetricsA);
    renderCompareSlot(state.compareB, dom.compareNameB, dom.compareMetricsB);

    const hint = state.compareA && state.compareB
        ? "Both regions loaded 鈥?scroll up to read the comparison"
        : state.compareA
            ? "Region A set 鈥?click another country to fill Region B"
            : "Compare mode active 鈥?click countries on the globe to fill slots";
    dom.compareHint.textContent = hint;
}

function updateEconomicPanel(country) {
    if (!country) {
        return;
    }

    const values = [
        { key: "bar2019", valueKey: "bar2019Value", value: country.gdp2019, color: "#2563eb" },
        { key: "bar2020", valueKey: "bar2020Value", value: country.gdp2020, color: "#be123c" },
        { key: "bar2021", valueKey: "bar2021Value", value: country.gdp2021, color: "#d97706" },
        { key: "bar2022", valueKey: "bar2022Value", value: country.gdp2022, color: "#3b82f6" },
        { key: "bar2023", valueKey: "bar2023Value", value: country.gdp2023, color: "#047857" }
    ];

    const scaleMax = Math.max(8, ...values.map((entry) => Math.abs(entry.value)));
    values.forEach((entry) => {
        const height = Math.max(8, (Math.abs(entry.value) / scaleMax) * 100);
        dom[entry.key].style.height = `${height}%`;
        dom[entry.key].style.background = entry.color;
        dom[entry.key].style.opacity = entry.value === 0 ? "0.4" : "1";
        dom[entry.valueKey].textContent = formatGrowth(entry.value);
        dom[entry.valueKey].style.color = entry.value < 0 ? "#be123c" : "#1e293b";
    });

    dom.shockChip.textContent = `Shock ${formatSigned(country.shock)} / Recovery ${formatSigned(country.recovery)}`;
    dom.chartCountry.textContent = `${country.name} GDP growth path and post-pandemic rebound`;
}

function refreshDerivedViews() {
    syncMapView();
}

function selectCountry(country) {
    if (!country) {
        return;
    }
    state.selectedCountry = country;
    const point = getTimePoint(country, state.selectedTimeIndex);
    dom.countryName.textContent = country.name;
    dom.casesValue.textContent = formatCompact(point.cases);
    dom.deathsValue.textContent = formatCompact(point.deaths);
    dom.shockValue.textContent = formatSigned(country.shock);
    dom.recoveryValue.textContent = formatSigned(country.recovery);
    updateEconomicPanel(country);
    if (state.selectedTimeIndex === 0 && country.iso3 === "CHN") {
        dom.detailNote.textContent =
            `${getSelectedLabel(state.selectedTimeIndex)} is treated as the opening stage of the earliest documented cluster in Wuhan, China. ` +
            `The globe starts from that origin signal and only later expands into broad global spread and visible economic shock.`;
        syncMapView();
        return;
    }
    dom.detailNote.textContent =
        `${getSelectedLabel(state.selectedTimeIndex)} sits in the "${point.phaseLabel}" phase. The market shows about ${formatCompact(point.cases)} cumulative cases, ` +
        `${point.gdp.toFixed(1)}% GDP growth on the mapped annual path, a 2019 to 2020 shock of ${formatSigned(country.shock)}, and a 2020 to 2023 recovery gap of ${formatSigned(country.recovery)}.`;
    syncMapView();
}

function hideTooltip() {
    dom.tooltip.style.display = "none";
}

function showTooltip(country, sx, sy) {
    const point = getTimePoint(country, state.selectedTimeIndex);
    dom.tooltip.style.display = "block";
    const sidebarReserve = 432;
    const tooltipLeft = Math.max(16, Math.min(sx + 14, window.innerWidth - sidebarReserve - 220));
    dom.tooltip.style.left = `${tooltipLeft}px`;
    dom.tooltip.style.top = `${Math.max(168, Math.min(window.innerHeight - 200, sy - 72))}px`;
    dom.tooltip.innerHTML = `
        <div style="font-weight:700;color:#1e293b;margin-bottom:6px;">${country.name}</div>
        <div>Time: <span style="color:#b45309">${getSelectedLabel(state.selectedTimeIndex)}</span></div>
        <div>Total cases: <span style="color:#2563eb">${formatCompact(point.cases)}</span></div>
        <div>GDP shock: <span style="color:#be123c">${formatSigned(country.shock)}</span></div>
        <div>Recovery: <span style="color:#047857">${formatSigned(country.recovery)}</span></div>
    `;
}

function handleCountryHover(country, sx, sy) {
    if (state.lockedCountryIso) {
        return;
    }
    if (!country) {
        hideTooltip();
        return;
    }
    selectCountry(country);
    showTooltip(country, sx, sy);
}

function handleCountryClick(country, sx, sy) {
    if (state.compareMode) {
        if (!country) {
            return;
        }
        if (state.compareSlotNext === "A") {
            state.compareA = country;
            state.compareSlotNext = "B";
        } else {
            state.compareB = country;
            state.compareSlotNext = "A";
        }
        renderComparePanel();
        selectCountry(country);
        showTooltip(country, sx, sy);
        return;
    }

    if (!country) {
        state.lockedCountryIso = null;
        globe.setLockedCountry(null);
        map2d.setSelected(null);
        hideTooltip();
        selectCountry(getLeadCountry());
        return;
    }

    state.lockedCountryIso = country.iso3;
    globe.setLockedCountry(country.iso3);
    map2d.setSelected(country.iso3);
    selectCountry(country);
    showTooltip(country, sx, sy);
}

function updateTimelineUI() {
    dom.timelineSlider.max = String(TIMELINE_DAYS.length - 1);
    dom.timelineSlider.value = String(state.selectedTimeIndex);
    const label = getSelectedLabel(state.selectedTimeIndex);
    dom.timelineValue.textContent = label;
    if (dom.timelineLabel) {
        dom.timelineLabel.textContent = label;
    }
}

function syncUrl() {
    const meta = getSelectedDayMeta(state.selectedTimeIndex);
    const url = new URL(window.location.href);
    url.searchParams.set("year", String(meta.year));
    url.searchParams.set("month", String(meta.month + 1));
    url.searchParams.set("day", String(meta.day));
    window.history.replaceState({}, "", url);
}

function applyTimeIndex(timeIndex) {
    state.selectedTimeIndex = Math.max(0, Math.min(TIMELINE_DAYS.length - 1, timeIndex));
    syncUrl();
    updateTimelineUI();
    globe.setTimeIndex(state.selectedTimeIndex);
    refreshDerivedViews();
    selectCountry(getLeadCountry());
    if (state.lockedCountryIso) {
        const locked = state.countries.find((item) => item.iso3 === state.lockedCountryIso);
        if (locked) {
            showTooltip(locked, 0, window.innerHeight * 0.48);
            globe.setLockedCountry(locked.iso3);
        }
    }
    if (state.compareMode) {
        renderComparePanel();
    }
    setStatus(`Timeline moved to ${getSelectedLabel(state.selectedTimeIndex)}. Inspect pandemic spread and economic conditions day by day.`);
}

function stopPlayback() {
    state.isPlaying = false;
    dom.playToggle.textContent = "Play";
    if (state.playTimer) {
        window.clearInterval(state.playTimer);
        state.playTimer = null;
    }
}

function startPlayback() {
    stopPlayback();
    state.isPlaying = true;
    dom.playToggle.textContent = "Pause";
    state.playTimer = window.setInterval(() => {
        if (state.selectedTimeIndex >= TIMELINE_DAYS.length - 1) {
            stopPlayback();
            return;
        }
        applyTimeIndex(state.selectedTimeIndex + 1);
    }, 42);
}

function bindEvents() {
    dom.modeToggle.addEventListener("click", () => {
        setViewMode(state.viewMode === "map2d" ? "globe" : "map2d");
    });

    dom.compareToggle.addEventListener("click", () => {
        state.compareMode = !state.compareMode;
        dom.comparePanel.hidden = !state.compareMode;
        dom.compareToggle.classList.toggle("active", state.compareMode);
        if (state.compareMode) {
            renderComparePanel();
        }
    });

    dom.compareClear.addEventListener("click", () => {
        state.compareA = null;
        state.compareB = null;
        state.compareSlotNext = "A";
        renderComparePanel();
    });

    dom.compareClose.addEventListener("click", () => {
        state.compareMode = false;
        state.compareA = null;
        state.compareB = null;
        state.compareSlotNext = "A";
        dom.comparePanel.hidden = true;
        dom.compareToggle.classList.remove("active");
    });

    dom.countrySearch.addEventListener("submit", (event) => {
        event.preventDefault();
        submitCountrySearch();
    });

    dom.countrySearchInput.addEventListener("input", () => {
        renderSearchResults(getCountrySearchMatches(dom.countrySearchInput.value), dom.countrySearchInput.value);
    });

    dom.countrySearchInput.addEventListener("focus", () => {
        renderSearchResults(getCountrySearchMatches(dom.countrySearchInput.value), dom.countrySearchInput.value);
    });

    dom.countrySearchInput.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            dom.countrySearchInput.blur();
            setSearchResultsVisible(false);
        }
    });

    dom.countrySearchResults.addEventListener("click", (event) => {
        const option = event.target.closest(".search-option");
        if (!option) {
            return;
        }
        const country = state.countries.find((item) => item.iso3 === option.dataset.iso3);
        selectCountryFromSearch(country);
    });

    document.addEventListener("pointerdown", (event) => {
        if (!dom.countrySearch.contains(event.target)) {
            setSearchResultsVisible(false);
        }
    });

    dom.timelineSlider.addEventListener("input", () => {
        applyTimeIndex(Number(dom.timelineSlider.value) || 0);
    });

    dom.playToggle.addEventListener("click", () => {
        if (state.isPlaying) {
            stopPlayback();
        } else {
            startPlayback();
        }
    });

    dom.jumpStart.addEventListener("click", () => {
        stopPlayback();
        applyTimeIndex(0);
    });

    window.addEventListener("keydown", (event) => {
        const target = event.target;
        const isTypingTarget = target instanceof HTMLElement && (
            target.tagName === "INPUT" ||
            target.tagName === "TEXTAREA" ||
            target.tagName === "SELECT" ||
            target.isContentEditable
        );
        if (isTypingTarget) {
            return;
        }

        if (event.code === "Space") {
            event.preventDefault();
            if (state.isPlaying) {
                stopPlayback();
            } else {
                startPlayback();
            }
        }
        if (event.code === "ArrowRight") {
            applyTimeIndex(state.selectedTimeIndex + 1);
        }
        if (event.code === "ArrowLeft") {
            applyTimeIndex(state.selectedTimeIndex - 1);
        }
    });
}

function getAssistantContext() {
    const country = state.selectedCountry || getLeadCountry();
    const point = country ? getTimePoint(country, state.selectedTimeIndex) : null;
    return {
        selectedLabel: getSelectedLabel(state.selectedTimeIndex),
        sourceSummary: state.sourceSummary,
        country: country ? {
            name: country.name,
            iso3: country.iso3,
            cases: country.cases,
            deaths: country.deaths,
            shock: country.shock,
            recovery: country.recovery,
            gdp2019: country.gdp2019,
            gdp2020: country.gdp2020,
            gdp2021: country.gdp2021,
            gdp2022: country.gdp2022,
            gdp2023: country.gdp2023
        } : null,
        point: point ? {
            cases: point.cases,
            deaths: point.deaths,
            gdp: point.gdp,
            shock: point.shock,
            recovery: point.recovery,
            phaseLabel: point.phaseLabel
        } : null
    };
}

async function hydrateHistoriesInBackground() {
    setStatus("Site is usable. Hydrating country histories in the background...");

    const historyTargets = state.countries.slice(0, config.historyCountryCount);
    const histories = await Promise.all(
        historyTargets.map((country) =>
            loadCountryHistory(country.name)
                .then((timeline) => ({ iso3: country.iso3, timeline }))
                .catch(() => ({ iso3: country.iso3, timeline: null }))
        )
    );

    const historyMap = Object.fromEntries(histories.map((entry) => [entry.iso3, entry.timeline]));
    state.countries = state.countries.map((country) => ({
        ...country,
        timeline: buildCountryTimeline(
            {
                cases: country.cases,
                deaths: country.deaths,
                population: country.population
            },
            {
                y2019: country.gdp2019,
                y2020: country.gdp2020,
                y2021: country.gdp2021,
                y2022: country.gdp2022,
                y2023: country.gdp2023
            },
            historyMap[country.iso3]
        )
    }));

    globe.setCountries(state.countries);
    refreshDerivedViews();
    selectCountry(getLeadCountry());
    if (state.lockedCountryIso) {
        globe.setLockedCountry(state.lockedCountryIso);
    }
    globe.setTimeIndex(state.selectedTimeIndex);
    setStatus("Site ready. Drag or play the daily timeline to inspect country-level pandemic and economic change.");
}

async function init() {
    bindEvents();
    updateTimelineUI();
    setLoading(true);
    setStatus("Loading world geometry and economic data...");

    let features = null;
    let covidRows = fallbackCovid;
    let gdpMap = fallbackGdp;

    try {
        [features, covidRows, gdpMap] = await Promise.all([
            loadWorldFeatures(),
            loadCovidRows(),
            loadGdpMap()
        ]);
        state.sourceSummary = "world-atlas + disease.sh + World Bank";
    } catch (error) {
        console.error(error);
        state.sourceSummary = "local fallback dataset";
    }

    const isLive = state.sourceSummary !== "local fallback dataset";
    dom.sourceStatusBadge.textContent = isLive ? "Live" : "Fallback";
    dom.sourceStatusBadge.className = `source-badge ${isLive ? "live" : "fallback"}`;
    // source detail is static in HTML; badge above reflects live/fallback state

    if (features) {
        globe.setFeatures(features);
        map2d.setFeatures(features);
    }

    setStatus("Building the first view...");
    state.countries = normalizeCountries(covidRows, gdpMap);

    globe.setCountries(state.countries);
    refreshDerivedViews();
    applyTimeIndex(state.selectedTimeIndex);
    selectCountry(getLeadCountry());
    setStatus("Initial view ready. Loading deeper historical series...");
    setLoading(false);
    void hydrateHistoriesInBackground();
}

init().catch((error) => {
    console.error(error);
    stopPlayback();
    setStatus("Initialization failed. Automatic flow stopped.");
    dom.sourceStatusBadge.textContent = "Fallback";
    dom.sourceStatusBadge.className = "source-badge fallback";
    setLoading(false);
});

initAiAssistant({ getContext: getAssistantContext });
