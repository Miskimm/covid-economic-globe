/** Draw simplified country boundaries and choropleth fills on a 2D equirectangular canvas */

import {
    buildCountryLookup,
    casesChoroplethValue,
    choroplethCss,
    choroplethT,
    computeChoroplethExtents,
    matchFeatureToCountry
} from "./choropleth.js";

function project(lng, lat, width, height) {
    return {
        x: ((lng + 180) / 360) * width,
        y: ((90 - lat) / 180) * height
    };
}

function traceFeaturePath(ctx, feature, width, height) {
    const geom = feature.geometry;
    if (!geom) {
        return;
    }
    const polys = geom.type === "Polygon" ? [geom.coordinates] : (geom.coordinates || []);
    if (!Array.isArray(polys)) {
        return;
    }

    for (const poly of polys) {
        if (!Array.isArray(poly)) {
            continue;
        }
        for (const ring of poly) {
            if (!Array.isArray(ring)) {
                continue;
            }
            if (!ring.length) {
                continue;
            }
            const start = project(ring[0][0], ring[0][1], width, height);
            ctx.moveTo(start.x, start.y);
            for (let i = 1; i < ring.length; i += 1) {
                const point = project(ring[i][0], ring[i][1], width, height);
                ctx.lineTo(point.x, point.y);
            }
            ctx.closePath();
        }
    }
}

export function buildFeaturePath2d(feature, width, height) {
    const path = new Path2D();
    const geom = feature.geometry;
    if (!geom) {
        return path;
    }
    const polys = geom.type === "Polygon" ? [geom.coordinates] : (geom.coordinates || []);
    if (!Array.isArray(polys)) {
        return path;
    }

    for (const poly of polys) {
        if (!Array.isArray(poly)) {
            continue;
        }
        for (const ring of poly) {
            if (!Array.isArray(ring)) {
                continue;
            }
            if (!ring.length) {
                continue;
            }
            const start = project(ring[0][0], ring[0][1], width, height);
            path.moveTo(start.x, start.y);
            for (let i = 1; i < ring.length; i += 1) {
                const point = project(ring[i][0], ring[i][1], width, height);
                path.lineTo(point.x, point.y);
            }
            path.closePath();
        }
    }

    return path;
}

export function drawWorldMap2d(ctx, features, width, height) {
    if (!features?.length || width < 10 || height < 10) {
        return;
    }

    ctx.fillStyle = "#dce4ed";
    ctx.strokeStyle = "#94a3b8";
    ctx.lineWidth = 0.6;

    for (const feature of features) {
        ctx.beginPath();
        traceFeaturePath(ctx, feature, width, height);
        ctx.fill();
        ctx.stroke();
    }
}

export function drawChoropleth2d(ctx, features, countries, timeIndex, width, height, options = {}) {
    if (!features?.length || width < 10 || height < 10) {
        return;
    }

    const { selectedIso = null, hoverIso = null } = options;
    const lookup = buildCountryLookup(countries);
    const extents = computeChoroplethExtents(countries, timeIndex);

    for (const feature of features) {
        const country = matchFeatureToCountry(feature, lookup);
        const value = country ? casesChoroplethValue(country, timeIndex) : 0;
        const hasData = value > 0;
        const t = choroplethT(value, extents);

        ctx.beginPath();
        traceFeaturePath(ctx, feature, width, height);
        ctx.fillStyle = choroplethCss(t, hasData);
        ctx.fill();

        const iso = country?.iso3 || null;
        const isSelected = iso && iso === selectedIso;
        const isHovered = iso && iso === hoverIso;
        ctx.strokeStyle = isSelected ? "#1d4ed8" : isHovered ? "#475569" : "#94a3b8";
        ctx.lineWidth = isSelected ? 1.8 : isHovered ? 1.2 : 0.55;
        ctx.stroke();
    }
}

export function hitTestChoropleth2d(features, countries, x, y, width, height) {
    if (!features?.length) {
        return null;
    }

    const lookup = buildCountryLookup(countries);
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    for (let index = features.length - 1; index >= 0; index -= 1) {
        const feature = features[index];
        const country = matchFeatureToCountry(feature, lookup);
        if (!country) {
            continue;
        }
        const path = buildFeaturePath2d(feature, width, height);
        if (ctx.isPointInPath(path, x, y)) {
            return country;
        }
    }

    return null;
}
