import * as THREE from "https://unpkg.com/three@0.160.0/build/three.module.js";
import {
    buildCountryLookup,
    casesChoroplethValue,
    choroplethHex,
    choroplethT,
    computeChoroplethExtents,
    matchFeatureToCountry
} from "./choropleth.js";

const config = {
    globeRadius: 1.88
};

function latLngToVector(lat, lng, radius) {
    const phi = (90 - lat) * Math.PI / 180;
    const theta = (lng + 180) * Math.PI / 180;
    return new THREE.Vector3(
        -radius * Math.sin(phi) * Math.cos(theta),
        radius * Math.cos(phi),
        radius * Math.sin(phi) * Math.sin(theta)
    );
}

export function createGlobe({ stage, initialTimeIndex, onCountryHover, onCountryClick }) {
    const state = {
        width: window.innerWidth,
        height: window.innerHeight,
        isDragging: false,
        pointerX: 0,
        pointerY: 0,
        lastX: 0,
        lastY: 0,
        pointerDownX: 0,
        pointerDownY: 0,
        yawVelocity: 0.0016,
        pitchVelocity: 0,
        pulse: 0,
        countries: [],
        selectedTimeIndex: initialTimeIndex,
        features: [],
        choroplethEntries: [],
        boundaryEntries: [],
        hoveredBoundary: null,
        lockedIso3: null
    };

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xe8f4fc, 7, 12);

    const camera = new THREE.PerspectiveCamera(36, state.width / state.height, 0.1, 100);
    camera.position.set(0, 0.18, 8.4);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
    renderer.setSize(state.width, state.height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    stage.appendChild(renderer.domElement);

    const globeGroup = new THREE.Group();
    globeGroup.rotation.x = 0.32;
    globeGroup.rotation.y = initialTimeIndex === 0 ? 2.25 : -0.58;
    scene.add(globeGroup);

    const starGroup = new THREE.Group();
    const landBaseGroup = new THREE.Group();
    const choroplethGroup = new THREE.Group();
    const boundaryGroup = new THREE.Group();
    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();

    scene.add(starGroup);
    globeGroup.add(landBaseGroup);
    globeGroup.add(choroplethGroup);
    globeGroup.add(boundaryGroup);

    scene.add(new THREE.AmbientLight(0xffffff, 0.95));

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.35);
    keyLight.position.set(4, 3, 6);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xe2e8f0, 0.45);
    rimLight.position.set(-5, 1, -3);
    scene.add(rimLight);

    const ocean = new THREE.Mesh(
        new THREE.SphereGeometry(config.globeRadius, 72, 72),
        new THREE.MeshStandardMaterial({
            color: 0x1d6fb8,
            roughness: 0.72,
            metalness: 0.04,
            emissive: 0x0c3d6e,
            emissiveIntensity: 0.12
        })
    );
    globeGroup.add(ocean);

    const atmosphere = new THREE.Mesh(
        new THREE.SphereGeometry(config.globeRadius * 1.05, 72, 72),
        new THREE.MeshBasicMaterial({
            color: 0x7dd3fc,
            transparent: true,
            opacity: 0.1,
            side: THREE.BackSide
        })
    );
    globeGroup.add(atmosphere);

    const outerShell = new THREE.Mesh(
        new THREE.SphereGeometry(config.globeRadius * 1.12, 48, 48),
        new THREE.MeshBasicMaterial({
            color: 0xcbd5e1,
            transparent: true,
            opacity: 0.06,
            side: THREE.BackSide
        })
    );
    globeGroup.add(outerShell);

    function addStars() {
        const geometry = new THREE.BufferGeometry();
        const positions = [];
        for (let i = 0; i < 520; i += 1) {
            const r = 16 + Math.random() * 14;
            const theta = Math.random() * Math.PI * 2;
            const phi = Math.acos(2 * Math.random() - 1);
            positions.push(
                r * Math.sin(phi) * Math.cos(theta),
                r * Math.cos(phi),
                r * Math.sin(phi) * Math.sin(theta)
            );
        }
        geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
        starGroup.add(new THREE.Points(geometry, new THREE.PointsMaterial({
            color: 0x94a3b8,
            size: 0.04,
            transparent: true,
            opacity: 0.35,
            sizeAttenuation: true
        })));
    }

    addStars();

    function clearObjectChildren(group) {
        while (group.children.length) {
            const child = group.children[group.children.length - 1];
            group.remove(child);
            if (child.geometry) child.geometry.dispose?.();
            if (child.material) child.material.dispose?.();
        }
    }

    function computeFeatureCenter(feature) {
        let sumLat = 0;
        let sumLng = 0;
        let count = 0;
        const polygons = feature.geometry?.type === "Polygon"
            ? [feature.geometry.coordinates]
            : feature.geometry?.type === "MultiPolygon"
                ? feature.geometry.coordinates
                : [];

        polygons.forEach((polygon) => {
            if (!Array.isArray(polygon)) {
                return;
            }
            polygon.forEach((ring) => {
                if (!Array.isArray(ring)) {
                    return;
                }
                ring.forEach(([lng, lat]) => {
                    sumLat += lat;
                    sumLng += lng;
                    count += 1;
                });
            });
        });

        return count ? { lat: sumLat / count, lng: sumLng / count } : { lat: 0, lng: 0 };
    }

    function buildBoundaryLines(features) {
        clearObjectChildren(boundaryGroup);
        state.boundaryEntries = [];
        const countryLookup = buildCountryLookup(state.countries);
        for (const feature of features) {
            if (!feature.geometry) continue;
            const positions = [];
            const polygons = feature.geometry.type === "Polygon"
                ? [feature.geometry.coordinates]
                : feature.geometry.type === "MultiPolygon"
                    ? feature.geometry.coordinates
                    : [];

            for (const polygon of polygons) {
                for (const ring of polygon) {
                    for (let i = 0; i < ring.length - 1; i += 1) {
                        const a = latLngToVector(ring[i][1], ring[i][0], config.globeRadius * 1.006);
                        const b = latLngToVector(ring[i + 1][1], ring[i + 1][0], config.globeRadius * 1.006);
                        positions.push(a.x, a.y, a.z, b.x, b.y, b.z);
                    }
                }
            }
            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
            const material = new THREE.LineBasicMaterial({
                color: 0x94a3b8,
                transparent: true,
                opacity: 0.45
            });
            const line = new THREE.LineSegments(geometry, material);
            const center = computeFeatureCenter(feature);
            const featureName = feature.properties?.name || "";
            const country = matchFeatureToCountry(feature, countryLookup);
            line.userData = {
                featureName,
                center,
                country,
                featureRef: feature
            };
            boundaryGroup.add(line);
            state.boundaryEntries.push({
                line,
                center,
                country
            });
        }
    }

    function buildLandMeshGeometry(feature, radius) {
        if (!feature.geometry) {
            return null;
        }

        const positions = [];
        const indices = [];
        const polygons = feature.geometry.type === "Polygon"
            ? [feature.geometry.coordinates]
            : feature.geometry.type === "MultiPolygon"
                ? feature.geometry.coordinates
                : [];

        for (const polygon of polygons) {
            if (!Array.isArray(polygon) || !polygon.length) {
                continue;
            }
            const ring = polygon[0];
            if (!Array.isArray(ring) || ring.length < 3) {
                continue;
            }

            const baseIndex = positions.length / 3;
            ring.forEach((coord) => {
                if (!Array.isArray(coord) || coord.length < 2) {
                    return;
                }
                const [lng, lat] = coord;
                const vector = latLngToVector(lat, lng, radius);
                positions.push(vector.x, vector.y, vector.z);
            });

            for (let i = 1; i < ring.length - 1; i += 1) {
                indices.push(baseIndex, baseIndex + i, baseIndex + i + 1);
            }
        }

        if (!indices.length) {
            return null;
        }

        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
        geometry.setIndex(indices);
        geometry.computeVertexNormals();
        return geometry;
    }

    function createCountryChoroplethMesh(feature, radius) {
        const geometry = buildLandMeshGeometry(feature, radius);
        if (!geometry) {
            return null;
        }

        return new THREE.Mesh(
            geometry,
            new THREE.MeshStandardMaterial({
                color: 0xf8fafc,
                emissive: 0x000000,
                emissiveIntensity: 0,
                roughness: 0.82,
                metalness: 0.01,
                side: THREE.FrontSide
            })
        );
    }

    function buildLandBase(features) {
        clearObjectChildren(landBaseGroup);

        for (const feature of features) {
            const geometry = buildLandMeshGeometry(feature, config.globeRadius * 1.002);
            if (!geometry) {
                continue;
            }

            const mesh = new THREE.Mesh(
                geometry,
                new THREE.MeshStandardMaterial({
                    color: 0xf8fafc,
                    roughness: 0.9,
                    metalness: 0,
                    side: THREE.FrontSide
                })
            );
            landBaseGroup.add(mesh);
        }
    }

    function buildChoropleth(features) {
        clearObjectChildren(choroplethGroup);
        state.choroplethEntries = [];
        const lookup = buildCountryLookup(state.countries);

        for (const feature of features) {
            const country = matchFeatureToCountry(feature, lookup);
            if (!country) {
                continue;
            }

            const mesh = createCountryChoroplethMesh(feature, config.globeRadius * 1.004);
            if (!mesh) {
                continue;
            }

            const entry = {
                mesh,
                country,
                center: computeFeatureCenter(feature)
            };
            mesh.userData.choroplethEntry = entry;
            choroplethGroup.add(mesh);
            state.choroplethEntries.push(entry);
        }

        updateChoroplethForTime();
    }

    function updateChoroplethForTime() {
        if (!state.choroplethEntries.length) {
            return;
        }

        const extents = computeChoroplethExtents(state.countries, state.selectedTimeIndex);
        state.choroplethEntries.forEach((entry) => {
            const value = casesChoroplethValue(entry.country, state.selectedTimeIndex);
            const t = choroplethT(value, extents);
            entry.mesh.material.color.setHex(choroplethHex(t, value > 0));
        });
    }

    function updateChoroplethHighlight(entry) {
        const activeIso3 = state.lockedIso3 || entry?.country?.iso3 || null;
        state.choroplethEntries.forEach((item) => {
            const isActive = activeIso3 ? item.country?.iso3 === activeIso3 : item === entry;
            item.mesh.material.emissive.setHex(isActive ? 0x1d4ed8 : 0x000000);
            item.mesh.material.emissiveIntensity = isActive ? 0.14 : 0;
        });
    }

    function updateBoundaryHighlight(entry) {
        const nextHoverLine = entry?.line || null;
        const previousHoverLine = state.hoveredBoundary?.line || null;
        if (previousHoverLine === nextHoverLine) {
            return;
        }
        const activeIso3 = state.lockedIso3 || entry?.country?.iso3 || null;
        state.boundaryEntries.forEach((item) => {
            const isActive = activeIso3 ? item.country?.iso3 === activeIso3 : false;
            item.line.material.color.set(isActive ? 0x1d4ed8 : 0x64748b);
            item.line.material.opacity = isActive ? 0.95 : 0.5;
        });

        state.hoveredBoundary = entry || null;
    }

    function getHoveredChoropleth() {
        pointerNdc.x = (state.pointerX / state.width) * 2 - 1;
        pointerNdc.y = -(state.pointerY / state.height) * 2 + 1;
        raycaster.setFromCamera(pointerNdc, camera);
        const hits = raycaster.intersectObjects(choroplethGroup.children, false);
        if (!hits.length) {
            return null;
        }
        return hits[0].object.userData.choroplethEntry || null;
    }

    function updateHover() {
        if (state.isDragging) {
            const lockedEntry = state.lockedIso3
                ? state.choroplethEntries.find((entry) => entry.country?.iso3 === state.lockedIso3) || null
                : null;
            updateBoundaryHighlight(lockedEntry);
            updateChoroplethHighlight(lockedEntry);
            if (!state.lockedIso3) {
                onCountryHover?.(null);
            }
            return;
        }

        if (state.lockedIso3) {
            const lockedEntry = state.choroplethEntries.find((entry) => entry.country?.iso3 === state.lockedIso3) || null;
            updateBoundaryHighlight(lockedEntry);
            updateChoroplethHighlight(lockedEntry);
            return;
        }

        const hovered = getHoveredChoropleth();
        if (!hovered?.country) {
            updateBoundaryHighlight(null);
            updateChoroplethHighlight(null);
            onCountryHover?.(null);
            return;
        }

        updateBoundaryHighlight(hovered);
        updateChoroplethHighlight(hovered);
        onCountryHover?.(hovered.country, state.pointerX, state.pointerY);
    }

    function animate() {
        requestAnimationFrame(animate);
        state.pulse += 0.016;

        if (!state.isDragging) {
            globeGroup.rotation.y += state.yawVelocity;
            globeGroup.rotation.x += state.pitchVelocity;
            state.yawVelocity *= 0.985;
            state.pitchVelocity *= 0.92;
            state.yawVelocity += 0.00002;
        }

        globeGroup.rotation.x = Math.max(-0.8, Math.min(0.8, globeGroup.rotation.x));

        outerShell.rotation.y += 0.00035;
        atmosphere.rotation.y -= 0.0002;

        updateHover();
        renderer.render(scene, camera);
    }

    renderer.domElement.addEventListener("pointerdown", (event) => {
        state.isDragging = true;
        state.pointerDownX = event.clientX;
        state.pointerDownY = event.clientY;
        state.lastX = event.clientX;
        state.lastY = event.clientY;
        state.pointerX = event.clientX;
        state.pointerY = event.clientY;
        if (!state.lockedIso3) {
            onCountryHover?.(null);
        }
    });

    window.addEventListener("pointermove", (event) => {
        state.pointerX = event.clientX;
        state.pointerY = event.clientY;
        if (!state.isDragging) {
            return;
        }
        const dx = event.clientX - state.lastX;
        const dy = event.clientY - state.lastY;
        globeGroup.rotation.y += dx * 0.0045;
        globeGroup.rotation.x += dy * 0.0034;
        state.yawVelocity = dx * 0.00022;
        state.pitchVelocity = dy * 0.00018;
        state.lastX = event.clientX;
        state.lastY = event.clientY;
    });

    window.addEventListener("pointerup", (event) => {
        state.pointerX = event.clientX;
        state.pointerY = event.clientY;
        const moved = Math.hypot(event.clientX - state.pointerDownX, event.clientY - state.pointerDownY);
        if (moved < 6) {
            const clicked = getHoveredChoropleth();
            state.lockedIso3 = clicked?.country?.iso3 || null;
            updateBoundaryHighlight(clicked || null);
            updateChoroplethHighlight(clicked || null);
            onCountryClick?.(clicked?.country || null, state.pointerX, state.pointerY);
        }
        state.isDragging = false;
    });

    function resize() {
        const bounds = stage.getBoundingClientRect();
        state.width = Math.max(1, Math.floor(bounds.width));
        state.height = Math.max(1, Math.floor(bounds.height));
        camera.aspect = state.width / state.height;
        camera.updateProjectionMatrix();
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
        renderer.setSize(state.width, state.height);
    }

    window.addEventListener("resize", resize, { passive: true });
    if (typeof ResizeObserver !== "undefined") {
        new ResizeObserver(resize).observe(stage);
    }
    resize();

    animate();

    return {
        setFeatures(features) {
            if (features) {
                state.features = features;
                buildLandBase(features);
                buildChoropleth(features);
                buildBoundaryLines(features);
            }
        },
        setCountries(countries) {
            state.countries = countries;
            state.hoveredBoundary = null;
            if (state.features.length) {
                buildChoropleth(state.features);
                buildBoundaryLines(state.features);
            }
            const lockedEntry = state.lockedIso3
                ? state.choroplethEntries.find((entry) => entry.country?.iso3 === state.lockedIso3) || null
                : null;
            updateBoundaryHighlight(lockedEntry);
            updateChoroplethHighlight(lockedEntry);
        },
        setTimeIndex(timeIndex) {
            state.selectedTimeIndex = timeIndex;
            updateChoroplethForTime();
        },
        setLockedCountry(iso3) {
            state.lockedIso3 = iso3 || null;
            const lockedEntry = state.lockedIso3
                ? state.choroplethEntries.find((entry) => entry.country?.iso3 === state.lockedIso3) || null
                : null;
            updateBoundaryHighlight(lockedEntry);
            updateChoroplethHighlight(lockedEntry);
        },
        getCanvas() {
            return renderer.domElement;
        }
    };
}
